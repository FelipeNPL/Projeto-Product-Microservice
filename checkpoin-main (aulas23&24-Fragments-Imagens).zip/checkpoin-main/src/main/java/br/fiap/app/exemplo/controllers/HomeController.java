package br.fiap.app.exemplo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	private Model addName(Model model) {
	return model.addAttribute("nome", "Trocar");
	}
	
	@RequestMapping("/")
	public String home(Model model ) {
		model.addAttribute("mensagem", "Enviado pelo servidor");
		addName(model);
		
		return "home";
	}

}
